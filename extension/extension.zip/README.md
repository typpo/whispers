Reference
- [Chrome app oauth setup](https://developer.chrome.com/docs/extensions/mv3/tut_oauth/)
- [Google API endpoint](https://stackoverflow.com/questions/7130648/get-user-info-via-google-api)
- [Audio in service workers](https://bugs.chromium.org/p/chromium/issues/detail?id=1131236) and [github](https://github.com/guest271314/sw-extension-audio/tree/main)
- [Black and White](https://www.youtube.com/watch?v=NPmU-PaKZf0) and [again](https://www.youtube.com/watch?v=VSIXZJFgBFA)
